//
//  THMediaItem.swift
//  AVFoundationMac
//
//  Created by Youk Chansim on 2017. 5. 21..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import AVFoundation

@objc
class THMediaItem: NSObject {
    typealias THCompletionHandler = (Bool) -> Void
    let COMMON_META_KEY = "commonMetadata"
    let AVAILABLE_META_KEY = "availableMetadataFormats"
    
    var fileName = ""
    var fileType = ""
    var metadata: THMetadata = THMetadata()
    var isEditable = true
    
    var url: URL?
    var asset: AVAsset?
    var acceptedFormats: [String] = []
    var prepared = true
    
    init(url: URL) {
        super.init()
        self.url = url
        asset = AVAsset(url: url)
        fileName = url.lastPathComponent
        isEditable = !(fileType == AVFileTypeMPEGLayer3)
        acceptedFormats = [
            AVMetadataFormatQuickTimeMetadata,
            AVMetadataFormatiTunesMetadata,
            AVMetadataFormatID3Metadata,
        ]
        fileType = fileTypeForURL(url: url)
    }
    
    func fileTypeForURL(url: URL) -> String {
        let ext = (NSString(string: url.lastPathComponent)).pathExtension
        var type = ""
        switch ext {
        case "m4a":
            type = AVFileTypeAppleM4A
        case "m4v":
            type = AVFileTypeAppleM4V
        case "mov":
            type = AVFileTypeQuickTimeMovie
        case "mp3":
            type = AVFileTypeMPEG4
        default:
            type = AVFileTypeMPEGLayer3
        }
        
        return type
    }
    
    func prepareWithCompletionHandler(completionHandler: @escaping THCompletionHandler) {
        if prepared {
            completionHandler(prepared)
            return
        }
        
        metadata = THMetadata()
        let keys = [
            COMMON_META_KEY,
            AVAILABLE_META_KEY,
        ]
        
        asset?.loadValuesAsynchronously(forKeys: keys) {
            let commonStatus = self.asset?.statusOfValue(forKey: self.COMMON_META_KEY, error: nil)
            let formatsStatus = self.asset?.statusOfValue(forKey: self.AVAILABLE_META_KEY, error: nil)
            
            self.prepared = (commonStatus == .loaded) && (formatsStatus == .loaded)
            if self.prepared {
                if let asset = self.asset {
                    for item in asset.commonMetadata {
                        self.metadata.addMetadataItem(item: item, key: item.commonKey ?? "")
                        
                        for format in asset.availableMetadataFormats {
                            if self.acceptedFormats.contains(format) {
                                let items = asset.metadata(forFormat: format)
                                for item in items {
                                    self.metadata.addMetadataItem(item: item, key: item.commonKey ?? "")
                                }
                            }
                        }
                    }
                }
            }
            completionHandler(self.prepared)
        }
    }
    
    func saveWithCompletionHandler(handler: @escaping THCompletionHandler) {
        guard let asset = self.asset else {
            return
        }
        
        let presetName = AVAssetExportPresetPassthrough
        let session = AVAssetExportSession(asset: asset, presetName: presetName)
        let outputURL = tempURL
        session?.outputURL = outputURL
        session?.outputFileType = fileType
        session?.metadata = metadata.metadataItems() as? [AVMetadataItem]
        
        session?.exportAsynchronously {
            let status = session?.status
            let success = status == .completed
            if success {
                if let sourceURL = self.url {
                    let manager = FileManager.default
                    try? manager.removeItem(at: sourceURL)
                    try? manager.moveItem(at: outputURL, to: sourceURL)
                    self.reset()
                }
            }
            
            DispatchQueue.main.async {
                handler(success)
            }
        }
    }
    
    var tempURL: URL {
        let tempDir = NSTemporaryDirectory()
        let ext = NSString(string: url?.lastPathComponent ?? "").pathExtension
        let tempName = "temp.\(ext)"
        let tempPath = tempDir + "/\(tempName)"
        return URL(fileURLWithPath: tempPath)
    }
    
    func reset() {
        prepared = false
        if let url = self.url {
            asset = AVAsset(url: url)
        }
    }
}
