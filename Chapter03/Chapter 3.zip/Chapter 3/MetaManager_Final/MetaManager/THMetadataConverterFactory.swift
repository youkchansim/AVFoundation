//
//  THMetadataConverterFactory.swift
//  AVFoundationMac
//
//  Created by Youk Chansim on 2017. 5. 21..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

class THMetadataConverterFactory: THDefaultMetadataConverter {
    func converter(key: String) -> THMetadataConverter {
        var converter: THMetadataConverter
        
        switch key {
        case THMetadataKeyArtwork:
            converter = THArtworkMetadataConverter()
        default:
            converter = THDefaultMetadataConverter()
        }
        
        return converter
    }
}
/*
 - (id <THMetadataConverter>)converterForKey:(NSString *)key {
 
 id <THMetadataConverter> converter = nil;
 
 if ([key isEqualToString:THMetadataKeyArtwork]) {
 converter = [[THArtworkMetadataConverter alloc] init];
 }
 else if ([key isEqualToString:THMetadataKeyTrackNumber]) {
 converter = [[THTrackMetadataConverter alloc] init];
 }
 else if ([key isEqualToString:THMetadataKeyDiscNumber]) {
 converter = [[THDiscMetadataConverter alloc] init];
 }
 else if ([key isEqualToString:THMetadataKeyComments]) {
 converter = [[THCommentMetadataConverter alloc] init];
 }
 else if ([key isEqualToString:THMetadataKeyGenre]) {
 converter = [[THGenreMetadataConverter alloc] init];
 }
 else {
 converter = [[THDefaultMetadataConverter alloc] init];
 }
 
 return converter;
 }
 */
