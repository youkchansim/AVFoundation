//
//  THMetadata.swift
//  AVFoundationMac
//
//  Created by Youk Chansim on 2017. 5. 21..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import AVFoundation
import AppKit

@objc
protocol THMetadataConverter {
    func displayValueFromMetadataItem(item: AVMetadataItem) -> Any?
    func metadataItemFromDisplayValue(value: Any, withMetadataItem item: AVMetadataItem) -> AVMetadataItem
}

class THArtworkMetadataConverter: THMetadataConverter {
    func displayValueFromMetadataItem(item: AVMetadataItem) -> Any? {
        var image: NSImage?
        if let data = item.value as? Data {
            image = NSImage(data: data)
        } else if let dic = item.value as? NSDictionary {
            if let data = dic["data"] as? Data {
                image = NSImage(data: data)
            }
        }
        
        return image
    }
    
    func metadataItemFromDisplayValue(value: Any, withMetadataItem item: AVMetadataItem) -> AVMetadataItem {
        let metadataItem: AVMutableMetadataItem = item.mutableCopy() as! AVMutableMetadataItem
        if let image = value as? NSImage {
            metadataItem.value = image.tiffRepresentation as (NSCopying & NSObjectProtocol)?
        }
        
        return metadataItem
    }
}

class THDefaultMetadataConverter: THMetadataConverter {
    func displayValueFromMetadataItem(item: AVMetadataItem) -> Any? {
        return item.value
    }
    
    func metadataItemFromDisplayValue(value: Any, withMetadataItem item: AVMetadataItem) -> AVMetadataItem {
        let metadataItem: AVMutableMetadataItem = item.mutableCopy() as! AVMutableMetadataItem
        metadataItem.value = value as? NSCopying & NSObjectProtocol
        return metadataItem
    }
}

class THCommentMetadataConverter: THMetadataConverter {
    func displayValueFromMetadataItem(item: AVMetadataItem) -> Any? {
        var value: String?
        
        if item.value is String {
            value = item.stringValue
        } else if let dic = item.value as? NSDictionary {
            if dic["identifier"] is String {
                if let text = dic["text"] as? String {
                    value = text
                }
            }
        }
        
        return value
    }
    
    func metadataItemFromDisplayValue(value: Any, withMetadataItem item: AVMetadataItem) -> AVMetadataItem {
        let metadataItem: AVMutableMetadataItem = item.mutableCopy() as! AVMutableMetadataItem
        metadataItem.value = value as? NSCopying & NSObjectProtocol
        return metadataItem
    }
}

class THTrackMetadataConverter: THMetadataConverter {
    func displayValueFromMetadataItem(item: AVMetadataItem) -> Any? {
        var number: UInt16 = 0
        var count: UInt16 = 0
        
        if item.value is String {
            let components = item.stringValue?.components(separatedBy: "/") ?? []
            number = UInt16(components[0]) ?? 0
            count = UInt16(components[1]) ?? 0
        } else if item.value is Data {
            if let data = item.dataValue {
                if data.count == 8 {
                    let values = data.withUnsafeBytes {
                        [UInt16](UnsafeBufferPointer(start: $0, count: data.count))
                    }
                    if values[1] > 0 {
                        number = CFSwapInt16BigToHost(values[1])
                    }
                    if values[2] > 0 {
                        count = CFSwapInt16BigToHost(values[2])
                    }
                }
            }
        }
        
        let dict = NSMutableDictionary()
        dict.setObject(number, forKey: THMetadataKeyTrackNumber as NSCopying)
        dict.setObject(count, forKey: THMetadataKeyTrackCount as NSCopying)
        
        return dict
    }
    
    func metadataItemFromDisplayValue(value: Any, withMetadataItem item: AVMetadataItem) -> AVMetadataItem {
        let metadataItem: AVMutableMetadataItem = item.mutableCopy() as! AVMutableMetadataItem
        let trackData = value as? NSDictionary
        let trackNumber = trackData?[THMetadataKeyTrackNumber] as? UInt16
        let trackCount = trackData?[THMetadataKeyTrackCount] as? UInt16
        
        var values: [UInt16] = [
            0,
            0,
            0,
            0,
        ]
        
        if let number = trackNumber {
            values[1] = CFSwapInt16HostToBig(number)
        }
        
        if let count = trackCount {
            values[2] = CFSwapInt16HostToBig(count)
        }
        
        let length = MemoryLayout.size(ofValue: values)
        metadataItem.value = Data(bytes: values, count: length) as NSCopying & NSObjectProtocol
        
        return metadataItem
    }
}

class THDiscMetadataConverter: THMetadataConverter {
    func displayValueFromMetadataItem(item: AVMetadataItem) -> Any? {
        var number: UInt16 = 0
        var count: UInt16 = 0
        
        if item.value is String {
            let components = item.stringValue?.components(separatedBy: "/") ?? []
            number = UInt16(components[0]) ?? 0
            count = UInt16(components[1]) ?? 0
        } else if item.value is Data {
            if let data = item.dataValue {
                if data.count == 6 {
                    let values = data.withUnsafeBytes {
                        [UInt16](UnsafeBufferPointer(start: $0, count: data.count))
                    }
                    if values[1] > 0 {
                        number = CFSwapInt16BigToHost(values[1])
                    }
                    if values[2] > 0 {
                        count = CFSwapInt16BigToHost(values[2])
                    }
                }
            }
        }
        
        let dict = NSMutableDictionary()
        dict.setObject(number, forKey: THMetadataKeyTrackNumber as NSCopying)
        dict.setObject(count, forKey: THMetadataKeyTrackCount as NSCopying)
        
        return dict
    }
    
    func metadataItemFromDisplayValue(value: Any, withMetadataItem item: AVMetadataItem) -> AVMetadataItem {
        let metadataItem: AVMutableMetadataItem = item.mutableCopy() as! AVMutableMetadataItem
        let trackData = value as? NSDictionary
        let trackNumber = trackData?[THMetadataKeyTrackNumber] as? UInt16
        let trackCount = trackData?[THMetadataKeyTrackCount] as? UInt16
        
        var values: [UInt16] = [
            0,
            0,
            0,
            0,
            ]
        
        if let number = trackNumber {
            values[1] = CFSwapInt16HostToBig(number)
        }
        
        if let count = trackCount {
            values[2] = CFSwapInt16HostToBig(count)
        }
        
        let length = MemoryLayout.size(ofValue: values)
        metadataItem.value = Data(bytes: values, count: length) as NSCopying & NSObjectProtocol
        
        return metadataItem
    }
}

class THGenreMetadataConverter: THMetadataConverter {
    func displayValueFromMetadataItem(item: AVMetadataItem) -> Any? {
        var genre = THGenre()
        
        if item.value is String {
            if item.keySpace == AVMetadataKeySpaceID3 {
                if let genreIndex = item.numberValue?.uintValue {
                    genre = THGenre.id3Genre(with: genreIndex)
                } else {
                    genre = THGenre.id3Genre(withName: item.stringValue ?? "")
                }
            } else {
                genre = THGenre.videoGenre(withName: item.stringValue ?? "")
            }
        } else if item.value is Data {
            if let data = item.dataValue {
                if data.count == 2 {
                    let values = data.withUnsafeBytes {
                        [UInt16](UnsafeBufferPointer(start: $0, count: data.count))
                    }
                    let genreIndex = CFSwapInt16BigToHost(values[0]) 
                    genre = THGenre.iTunesGenre(with: UInt(genreIndex))
                }
            }
        }
        
        return genre
    }
    
    func metadataItemFromDisplayValue(value: Any, withMetadataItem item: AVMetadataItem) -> AVMetadataItem {
        let metadataItem: AVMutableMetadataItem = item.mutableCopy() as! AVMutableMetadataItem
        let genre = value as? THGenre
        if item.value is String {
            metadataItem.value = genre?.name as (NSCopying & NSObjectProtocol)?
        } else if item.value is Data {
            if let data = item.dataValue {
                if data.count == 2 {
                    let value = CFSwapInt16HostToBig(UInt16((genre?.index ?? 0) + 1))
                    let length = MemoryLayout.size(ofValue: value)
                    let pointer = UnsafeMutablePointer<UInt16>.allocate(capacity: length)
                    metadataItem.value = Data(bytes: pointer, count: length) as NSCopying & NSObjectProtocol
                }
            }
        }
        
        return metadataItem
    }
}
