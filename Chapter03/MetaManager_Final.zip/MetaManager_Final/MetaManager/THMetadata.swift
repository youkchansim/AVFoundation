//
//  THMetadataItem.swift
//  AVFoundationMac
//
//  Created by Youk Chansim on 2017. 5. 21..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

import Foundation
import AVFoundation
import AppKit

let THMetadataKeyName = "name"
let THMetadataKeyArtist = "artist"
let THMetadataKeyAlbumArtist = "albumArtist"
let THMetadataKeyArtwork = "artwork"
let THMetadataKeyAlbum = "album"
let THMetadataKeyYear = "year"
let THMetadataKeyBPM = "bpm"
let THMetadataKeyGrouping = "grouping"
let THMetadataKeyTrackNumber = "trackNumber"
let THMetadataKeyTrackCount = "trackCount"
let THMetadataKeyComposer = "composer"
let THMetadataKeyDiscNumber = "discNumber"
let THMetadataKeyDiscCount = "discCount"
let THMetadataKeyComments = "comments"
let THMetadataKeyGenre = "genre"

@objc
class THMetadata: NSObject {
    var name = ""
    var artist = ""
    var albumArtist = ""
    var album = ""
    var grouping = ""
    var composer = ""
    var comments = ""
    var artwork = NSImage()
    var genre: THGenre?
    
    var year = ""
    var bpm = 0
    var trackNumber = 0
    var trackCount = 0
    var discNumber = 0
    var discCount = 0
    
    var keyMapping = NSDictionary()
    var metadata = NSMutableDictionary()
    var converterFactory = THMetadataConverterFactory()
    
    func buildKeyMapping() -> NSDictionary {
        return [
            // Name Mapping
            AVMetadataCommonKeyTitle : THMetadataKeyName,
            
            // Artist Mapping
            AVMetadataCommonKeyArtist : THMetadataKeyArtist,
            AVMetadataQuickTimeMetadataKeyProducer : THMetadataKeyArtist,
            
            // Album Artist Mapping
            AVMetadataID3MetadataKeyBand : THMetadataKeyAlbumArtist,
            AVMetadataiTunesMetadataKeyAlbumArtist : THMetadataKeyAlbumArtist,
            "TP2" : THMetadataKeyAlbumArtist,
            
            // Album Mapping
            AVMetadataCommonKeyAlbumName : THMetadataKeyAlbum,
            
            // Artwork Mapping
            AVMetadataCommonKeyArtwork : THMetadataKeyArtwork,
            
            // Year Mapping
            AVMetadataCommonKeyCreationDate : THMetadataKeyYear,
            AVMetadataID3MetadataKeyYear : THMetadataKeyYear,
            "TYE" : THMetadataKeyYear,
            AVMetadataQuickTimeMetadataKeyYear : THMetadataKeyYear,
            AVMetadataID3MetadataKeyRecordingTime : THMetadataKeyYear,
            
            // BPM Mapping
            AVMetadataiTunesMetadataKeyBeatsPerMin : THMetadataKeyBPM,
            AVMetadataID3MetadataKeyBeatsPerMinute : THMetadataKeyBPM,
            "TBP" : THMetadataKeyBPM,
            
            // Grouping Mapping
            AVMetadataiTunesMetadataKeyGrouping : THMetadataKeyGrouping,
            "grp" : THMetadataKeyGrouping,
            AVMetadataCommonKeySubject : THMetadataKeyGrouping,
            
            // Track Number Mapping
            AVMetadataiTunesMetadataKeyTrackNumber : THMetadataKeyTrackNumber,
            AVMetadataID3MetadataKeyTrackNumber : THMetadataKeyTrackNumber,
            "TRK" : THMetadataKeyTrackNumber,
            
            // Composer Mapping
            AVMetadataQuickTimeMetadataKeyDirector : THMetadataKeyComposer,
            AVMetadataiTunesMetadataKeyComposer : THMetadataKeyComposer,
            AVMetadataCommonKeyCreator : THMetadataKeyComposer,
            
            // Disc Number Mapping
            AVMetadataiTunesMetadataKeyDiscNumber : THMetadataKeyDiscNumber,
            AVMetadataID3MetadataKeyPartOfASet : THMetadataKeyDiscNumber,
            "TPA" : THMetadataKeyDiscNumber,
            
            // Comments Mapping
            "ldes" : THMetadataKeyComments,
            AVMetadataCommonKeyDescription : THMetadataKeyComments,
            AVMetadataiTunesMetadataKeyUserComment : THMetadataKeyComments,
            AVMetadataID3MetadataKeyComments : THMetadataKeyComments,
            "COM" : THMetadataKeyComments,
            
            // Genre Mapping
            AVMetadataQuickTimeMetadataKeyGenre : THMetadataKeyGenre,
            AVMetadataiTunesMetadataKeyUserGenre : THMetadataKeyGenre,
            AVMetadataCommonKeyType : THMetadataKeyGenre
        ]
    }
    
    func addMetadataItem(item: AVMetadataItem, key: String) {
        if let normalizedKey = keyMapping[key] as? String {
            let converter = converterFactory.converter(key: normalizedKey)
            let value = converter.displayValueFromMetadataItem(item: item)
            if let dic = value as? NSDictionary {
                for currentKey in dic.allKeys {
                    if let key = currentKey as? String {
                        setValue(dic[key], forKey: key)
                    }
                }
            } else {
                setValue(value, forKey: normalizedKey)
            }
            
            metadata[normalizedKey] = item
        }
    }
    
    func metadataItems() -> NSArray {
        let items = NSMutableArray()
        
        addMetadataItemForNumber(trackNumber, count: trackCount, numberKey: THMetadataKeyTrackNumber, countKey: THMetadataKeyTrackCount, toArray: items)
        addMetadataItemForNumber(discNumber, count: discCount, numberKey: THMetadataKeyDiscNumber, countKey: THMetadataKeyDiscCount, toArray: items)
        
        let metaDict = metadata.mutableCopy() as! NSMutableDictionary
        metaDict.removeObject(forKey: THMetadataKeyTrackNumber)
        metaDict.removeObject(forKey: THMetadataKeyDiscNumber)
        
        for key in metaDict.allKeys {
            if let k = key as? String {
                let converter = converterFactory.converter(key: k)
                
                if let value = self.value(forKey: k), let metadataItem = metaDict[key] as? AVMetadataItem {
                    let item = converter.metadataItemFromDisplayValue(value: value, withMetadataItem: metadataItem)
                    items.add(item)
                }
            }
        }
        
        return items
    }
    
    func addMetadataItemForNumber(_ number: Int, count: Int, numberKey: String, countKey: String, toArray items: NSMutableArray) {
        let converter = converterFactory.converter(key: numberKey)
        let data = [
            numberKey: number,
            countKey: count
            ]
        
        if let sourceItem = metadata[numberKey] as? AVMetadataItem{
            let item = converter.metadataItemFromDisplayValue(value: data, withMetadataItem: sourceItem)
            items.add(item)
        }
    }
}
