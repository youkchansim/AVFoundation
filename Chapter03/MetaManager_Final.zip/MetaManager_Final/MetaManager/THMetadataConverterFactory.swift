//
//  THMetadataConverterFactory.swift
//  AVFoundationMac
//
//  Created by Youk Chansim on 2017. 5. 21..
//  Copyright © 2017년 Youk Chansim. All rights reserved.
//

class THMetadataConverterFactory: THDefaultMetadataConverter {
    func converter(key: String) -> THMetadataConverter {
        var converter: THMetadataConverter
        
        switch key {
        case THMetadataKeyArtwork:
            converter = THArtworkMetadataConverter()
        case THMetadataKeyTrackNumber:
            converter = THTrackMetadataConverter()
        case THMetadataKeyDiscNumber:
            converter = THDiscMetadataConverter()
        case THMetadataKeyComments:
            converter = THCommentMetadataConverter()
        case THMetadataKeyGenre:
            converter = THGenreMetadataConverter()
        default:
            converter = THDefaultMetadataConverter()
        }
        
        return converter
    }
}
