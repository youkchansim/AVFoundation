//
//  main.m
//  MetaManager
//
//  Created by Bob McCune on 7/19/13.
//  Copyright (c) 2013 TapHarmonic, LLC. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[]) {
    return NSApplicationMain(argc, (const char **) argv);
}
