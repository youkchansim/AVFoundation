//
//  THPlayerView.swift
//  VideoPlayer
//
//  Created by Youk Chansim on 2017. 5. 28..
//  Copyright © 2017년 TapHarmonic, LLC. All rights reserved.
//

import UIKit
import AVFoundation

@objc
class THPlayerView: UIView {
    
    @IBOutlet var overlayView: THOverlayView!
    
    override class var layerClass: AnyClass {
        return AVPlayerLayer.self
    }
    
    init(player: AVPlayer) {
        super.init(frame: CGRect.zero)
        
        backgroundColor = .black
        autoresizingMask = [.flexibleHeight, .flexibleWidth]
        
        if let playerLayer = layer as? AVPlayerLayer {
            playerLayer.player = player
        }
        
        Bundle.main.loadNibNamed("THOverlayView", owner: self, options: nil)
        
        addSubview(overlayView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.overlayView.frame = bounds
    }
    
    func transport() -> THTransport {
        return overlayView
    }
}
