//
//  THDocument.swift
//  KitTime Player
//
//  Created by Youk Chansim on 2017. 6. 1..
//  Copyright © 2017년 Bob McCune. All rights reserved.
//

import Foundation
import AVKit
import Cocoa

class THDocument: NSDocument {
    @IBOutlet weak var playerView: AVPlayerView!
    
    let STATUS_KEY = "status"
    var asset: AVAsset?
    var playerItem: AVPlayerItem?
    var chapters: NSArray?
    var exportSession: AVAssetExportSession?
    var exportController: THExportWindowController?
    
    var modernizing = false
    
    @IBAction func startTrimming(sender: Any) {
        playerView.beginTrimming(completionHandler: nil)
    }
    
    @IBAction func startExporting(sender: Any) {
        playerView.player?.pause()
        let savePanel = NSSavePanel()
        
        if let window = windowForSheet {
            savePanel.beginSheetModal(for: window) {
                if $0 == NSFileHandlingPanelOKButton {
                    savePanel.orderOut(nil)
                    
                    let preset = AVAssetExportPresetAppleM4V720pHD
                    if let asset = self.asset {
                        self.exportSession = AVAssetExportSession(asset: asset, presetName: preset)
                        
                        if let startTime = self.playerItem?.reversePlaybackEndTime, let endTime = self.playerItem?.forwardPlaybackEndTime {
                            let timeRange = CMTimeRange(start: startTime, end: endTime)
                            
                            self.exportSession?.timeRange = timeRange
                            self.exportSession?.outputFileType = self.exportSession?.supportedFileTypes.first
                            self.exportSession?.outputURL = savePanel.url
                            
                            self.exportController = THExportWindowController()
                            self.exportController?.exportSession = self.exportSession
                            self.exportController?.delegate = self
                            if let exportControllerWindow = self.exportController?.window {
                                window.beginSheet(exportControllerWindow, completionHandler: nil)
                                self.exportSession?.exportAsynchronously {
                                    window.endSheet(exportControllerWindow)
                                    self.exportController = nil
                                    self.exportSession = nil
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    override var windowNibName: String {
        return "THDocument"
    }
    
    override func windowControllerDidLoadNib(_ controller: NSWindowController) {
        super.windowControllerDidLoadNib(controller)
        
        if !modernizing {
            if let url = fileURL {
                setupPlayerbackStack(with: url)
            }
        } else {
            if let window = controller.window as? THWindow {
                window.showConvertingView()
            }
        }
    }
    
    func readFromURL(url: URL, ofType typeName: String, error: Error) -> Bool {
        return true
    }
    
    func tempURLForURL(url: URL) -> URL? {
        let fileManager = FileManager.default
        if let dirPath = fileManager.temporaryDirectory(withTemplateString: "kittime.XXXXXX") {
            let filePath = dirPath.appending("/\(url.lastPathComponent)")
            return URL(fileURLWithPath: filePath)
        }
        
        return nil
    }
    
    func setupPlayerbackStack(with url: URL) {
        asset = AVAsset(url: url)

        let keys = [
            "commonMetadata",
            "availableChapterLocales",
            ]
        
        if let asset = self.asset {
            playerItem = AVPlayerItem(asset: asset, automaticallyLoadedAssetKeys: keys)
            
            if let playerItem = self.playerItem {
                playerItem.addObserver(self, forKeyPath: STATUS_KEY, options: .new, context: nil)
                playerView.player = AVPlayer(playerItem: playerItem)
                playerView.showsSharingServiceButton = true
            }
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == STATUS_KEY {
            if playerItem?.status == .readyToPlay {
                if let title = titleForAsset(asset: asset) {
                    windowForSheet?.title = title
                    chapters = chaptersForAsset(asset: asset) as NSArray?
                    if chapters?.count ?? 0 > 0 {
                        setupActionMenu()
                    }
                    playerItem?.removeObserver(self, forKeyPath: STATUS_KEY)
                }
            }
        }
    }
    
    func titleInMetadata(metadata: [AVMetadataItem]) -> String? {
        let items = AVMetadataItem.metadataItems(from: metadata, withKey: AVMetadataCommonKeyTitle, keySpace: AVMetadataKeySpaceCommon)
        return items.first?.stringValue
    }
    
    func titleForAsset(asset: AVAsset?) -> String? {
        guard let asset = asset else {
            return nil
        }
        
        if let title = titleInMetadata(metadata: asset.commonMetadata) {
            if !title.isEmpty {
                return title
            }
        }
        
        return nil
    }
    
    func chaptersForAsset(asset: AVAsset?) -> [THChapter]? {
        guard let asset = asset else {
            return nil
        }
        
        let languages = Locale.preferredLanguages
        let metadataGroups = asset.chapterMetadataGroups(bestMatchingPreferredLanguages: languages)
        var chapters: [THChapter] = []
        metadataGroups.enumerated().forEach {
            let time = $0.element.timeRange.start
            let number = $0.offset
            let title = titleInMetadata(metadata: $0.element.items)
            
            if let chapter = THChapter(time: time, number: UInt(number), title: title) {
                chapters.append(chapter)
            }
        }
        
        return chapters
    }
    
    func setupActionMenu() {
        let menu = NSMenu()
        menu.addItem(NSMenuItem(title: "Previous Chapter", action: #selector(previousChapter), keyEquivalent: ""))
        menu.addItem(NSMenuItem(title: "Next Chapter", action: #selector(nextChapter), keyEquivalent: ""))
        
        playerView.actionPopUpButtonMenu = menu
    }
    
    func previousChapter(sender: Any?) {
        skipToChapter(findChapter: findPreviousChapter)
    }
    
    func nextChapter(sender: Any?) {
        skipToChapter(findChapter: findNextChapter)
    }
    
    func skipToChapter(findChapter: () -> THChapter?) {
        guard let chapter = findChapter() else {
            return
        }
        
        playerItem?.seek(to: chapter.time) { _ in
            self.playerView.flashChapterNumber(Int(chapter.number), chapterTitle: chapter.title)
        }
    }
    
    func findPreviousChapter() -> THChapter? {
        guard let item = playerItem else {
            return nil
        }
        
        let playerTime = item.currentTime()
        let currentTime = CMTimeSubtract(playerTime, CMTimeMake(3,1))
        let pastTime = kCMTimeNegativeInfinity
        let timeRange = CMTimeRangeMake(pastTime, currentTime)
        return findChapterInTimeRange(timeRange: timeRange, reverse: true)
    }
    
    func findNextChapter() -> THChapter? {
        guard let item = playerItem else {
            return nil
        }
        
        let currentTime = item.currentTime()
        let futureTime = kCMTimePositiveInfinity
        let timeRange = CMTimeRangeMake(currentTime, futureTime)
        return findChapterInTimeRange(timeRange: timeRange, reverse: false)
    }
    
    func findChapterInTimeRange(timeRange: CMTimeRange, reverse: Bool) -> THChapter? {
        var matchingChapter: THChapter?
        
        let options: NSEnumerationOptions = reverse ? .reverse : NSEnumerationOptions(rawValue: 0)
        chapters?.enumerateObjects(options: options) { obj, idx, stop in
            if let chapter = obj as? THChapter {
                if chapter.is(in: timeRange) {
                    matchingChapter = chapter
                    stop.pointee = true
                }
            }
        }
        
        return matchingChapter
    }
    
    override func validateUserInterfaceItem(_ item: NSValidatedUserInterfaceItem) -> Bool {
        let action = item.action
        if action == #selector(startTrimming(sender:)) {
            return playerView.canBeginTrimming
        }
        
        return true
    }
}

extension THDocument: THExportWindowControllerDelegate {
    func exportDidCancel() {
        exportSession?.cancelExport()
    }
}
