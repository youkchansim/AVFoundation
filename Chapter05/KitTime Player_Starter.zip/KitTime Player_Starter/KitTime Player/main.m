//
//  main.m
//  KitTime Player
//
//  Created by Bob McCune on 10/8/13.
//  Copyright (c) 2013 Bob McCune. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
