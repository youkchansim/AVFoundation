//
//  main.m
//  FaceKamera
//
//  Created by Bob McCune on 2/4/14.
//  Copyright (c) 2014 TapHarmonic, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "THAppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([THAppDelegate class]));
	}
}
